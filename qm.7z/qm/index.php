<!-- Quickmessage input --->
<?php
	//Open the file and read contents
	$qmReadFile = fopen('qm.message', 'rb');
	$read = fgetcsv($qmReadFile, ',');
	fclose($qmReadFile);
	
	//If the user submitted a message, prepare string to write to file
	if ($_POST['qm']) {
		echo '<strong>Message updated</strong>';
		$csv = $_POST['qm'] . "," . $_POST['active'];

		//Open file for reading/writing, and perform write
		$file = fopen('qm.message', 'w');
		if ($file) {
			fwrite($file, $csv);
			fclose($file);
		};
	};
?>

<?php echo '<p>' . $_POST['submittedTrue'] . '</p>'; ?>

<form action="index.php" method="post">
<?php echo '<p>Current message: <em>' . $read[0] . '</em></p>' ?>

<input name="qm" type="text" size="60" value=" />
<input name="active" type="checkbox" value="checked" />
<input type="hidden" name="submittedTrue" value=1 />
<input type="submit" />
</form>
