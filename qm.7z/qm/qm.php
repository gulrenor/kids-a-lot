<link rel = "stylesheet" type = "text/css" href = "qm.css">

<?php 
	//Open file and read as CSV
	$file = fopen('qm.message', 'rb');
	$read = fgetcsv($file, ',');	

	//If the message is active, then display it
	if ($read[1] == "checked") {
		echo '<div id="qm"><h1>';
		echo $read[0];
		echo '</h1></div>';
		};
	
?>